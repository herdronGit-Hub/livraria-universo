function enviarPergunta() {
    const pergunta = document.getElementById('pergunta').value;
    const chatbox = document.getElementById('chatbox');
    chatbox.innerHTML += `<p><strong>Você:</strong> ${pergunta}</p>`;

    fetch('/recomendacoes/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `pergunta=${encodeURIComponent(pergunta)}`
    })
    .then(response => response.text())
    .then(resposta => {
        chatbox.innerHTML += `<p><strong>Chatbot:</strong> ${resposta}</p>`;
        chatbox.scrollTop = chatbox.scrollHeight;
    });

    document.getElementById('pergunta').value = '';
}