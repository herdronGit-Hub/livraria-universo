-- Desativar verificação de chaves estrangeiras temporariamente
SET FOREIGN_KEY_CHECKS = 0;


-- Criar tabela clientes
CREATE TABLE IF NOT EXISTS clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE,
    senha VARCHAR(255),
    ativo BOOLEAN DEFAULT TRUE
);

-- Criar tabela enderecos
CREATE TABLE IF NOT EXISTS enderecos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    tipo_residencia VARCHAR(50),
    tipo_logradouro VARCHAR(50),
    logradouro VARCHAR(255),
    numero VARCHAR(10),
    bairro VARCHAR(255),
    cep VARCHAR(9),
    cidade VARCHAR(255),
    estado VARCHAR(2),
    entrega BOOLEAN,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- Criar tabela telefones
CREATE TABLE IF NOT EXISTS telefones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    tipo VARCHAR(20),
    ddd VARCHAR(2),
    numero VARCHAR(9),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- Criar tabela cartoes_credito
CREATE TABLE IF NOT EXISTS cartoes_credito (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    numero_cartao VARCHAR(16),
    nome_titular VARCHAR(255),
    bandeira VARCHAR(50),
    codigo_seguranca VARCHAR(4),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- Criar tabela pedidos
CREATE TABLE IF NOT EXISTS pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    data_pedido DATETIME,
    total DOUBLE,
    status VARCHAR(50),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- Criar tabela grupos_precificacao
CREATE TABLE IF NOT EXISTS grupos_precificacao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    margem_lucro DECIMAL(5,2)
);

-- Criar tabela categorias
CREATE TABLE IF NOT EXISTS categorias (
    id INT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL
);

-- Criar tabela livros
CREATE TABLE IF NOT EXISTS livros (
    id INT PRIMARY KEY,
    autor VARCHAR(255) NOT NULL,
    ano VARCHAR(4),
    titulo VARCHAR(255) NOT NULL,
    editora VARCHAR(255),
    edicao VARCHAR(10),
    isbn VARCHAR(13),
    numero_paginas INT,
    sinopse TEXT,
    altura DECIMAL(5,2),
    largura DECIMAL(5,2),
    peso DECIMAL(5,2),
    profundidade DECIMAL(5,2),
    codigo_barras VARCHAR(13),
    preco DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL,
    ativo BOOLEAN DEFAULT TRUE,
    grupo_precificacao_id INT,
    FOREIGN KEY (grupo_precificacao_id) REFERENCES grupos_precificacao(id)
);

-- Criar tabela livro_categoria (tabela de junção)
CREATE TABLE IF NOT EXISTS livro_categoria (
    livro_id INT,
    categoria_id INT,
    FOREIGN KEY (livro_id) REFERENCES livros(id),
    FOREIGN KEY (categoria_id) REFERENCES categorias(id),
    PRIMARY KEY (livro_id, categoria_id)
);

-- Criar tabela cupons
CREATE TABLE IF NOT EXISTS cupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(50) UNIQUE,
    desconto DECIMAL(5,2),
    valido_ate DATE
);

-- Criar tabela bandeiras
CREATE TABLE IF NOT EXISTS bandeiras (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL
);

-- Criar tabela carrinho (adicionada dos logs)
CREATE TABLE IF NOT EXISTS carrinho (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- Criar tabela recomendacoes (adicionada dos logs)
CREATE TABLE IF NOT EXISTS recomendacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- Reativar verificação de chaves estrangeiras
SET FOREIGN_KEY_CHECKS = 1;