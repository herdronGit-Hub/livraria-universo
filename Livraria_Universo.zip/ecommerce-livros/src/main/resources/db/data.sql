-- Clientes (senhas criptografadas com BCrypt)
INSERT IGNORE INTO clientes (nome, email, senha, ativo) VALUES
('João Silva', 'joao.silva@email.com', '$2a$10$XURP2Z3g7xOeh4W.g7u2yOx8z4bKxZ7lQw5eYd8Qz8Qz8Qz8Qz8Qz', TRUE),
('Maria Oliveira', 'maria.oliveira@email.com', '$2a$10$Y2J1Y2sgaXMgYSBzdXBlciBzdGFyIQ$X3Qz8z8Qz8Qz8Qz8Qz8Qz8Qz8Qz8Qz', TRUE);

-- Endereços
INSERT IGNORE INTO enderecos (cliente_id, tipo_residencia, tipo_logradouro, logradouro, numero, bairro, cep, cidade, estado, entrega) VALUES
(1, 'Casa', 'Rua', 'das Flores', '123', 'Centro', '12345-678', 'São Paulo', 'SP', FALSE),
(1, 'Apartamento', 'Avenida', 'Brasil', '456', 'Jardim América', '98765-432', 'São Paulo', 'SP', TRUE),
(2, 'Casa', 'Rua', 'do Sol', '789', 'Vila Nova', '54321-987', 'São Paulo', 'SP', TRUE);

-- Telefones
INSERT IGNORE INTO telefones (cliente_id, tipo, ddd, numero) VALUES
(1, 'Celular', '11', '987654321'),
(1, 'Fixo', '11', '33334444'),
(2, 'Celular', '11', '912345678');

-- Cartões de Crédito
INSERT IGNORE INTO cartoes_credito (cliente_id, numero_cartao, nome_titular, bandeira, codigo_seguranca) VALUES
(1, '1234567812345678', 'João Silva', 'Visa', '123'),
(1, '5555666677778888', 'João Silva', 'Mastercard', '456'),
(2, '8765432187654321', 'Maria Oliveira', 'Mastercard', '789');

-- Pedidos
INSERT IGNORE INTO pedidos (cliente_id, data_pedido, total, status) VALUES
(1, '2025-03-01 10:00:00', 59.90, 'Concluído'),
(1, '2025-03-05 14:30:00', 29.90, 'Concluído');

-- Grupos de Precificação
INSERT IGNORE INTO grupos_precificacao (nome, margem_lucro) VALUES
('Padrão', 30.00),
('Premium', 50.00);

-- Categorias
INSERT IGNORE INTO categorias (id, nome) VALUES
(1, 'Fantasia'),
(2, 'Distopia'),
(3, 'Clássico');

-- Livros
INSERT IGNORE INTO livros (id, autor, ano, titulo, editora, edicao, isbn, numero_paginas, sinopse, altura, largura, peso, profundidade, codigo_barras, preco, estoque, ativo, grupo_precificacao_id) VALUES
(1, 'J.R.R. Tolkien', '1954', 'O Senhor dos Anéis', 'Allen & Unwin', '1ª', '9780345339706', 1178, 'Uma aventura épica...', 23.5, 15.5, 1.2, 5.0, '1234567890123', 59.90, 10, TRUE, 1),
(2, 'George Orwell', '1949', '1984', 'Secker & Warburg', '1ª', '9780451524935', 328, 'Uma distopia sobre vigilância...', 20.0, 13.0, 0.4, 2.5, '9876543210987', 29.90, 15, TRUE, 1);

-- Livro_Categoria
INSERT IGNORE INTO livro_categoria (livro_id, categoria_id) VALUES
(1, 1),
(2, 2);

-- Cupons
INSERT IGNORE INTO cupons (codigo, desconto, valido_ate) VALUES
('DESC10', 10.00, '2025-12-31'),
('FRETEGRATIS', 15.00, '2025-06-30');

-- Bandeiras
INSERT IGNORE INTO bandeiras (nome) VALUES
('Visa'),
('Mastercard');