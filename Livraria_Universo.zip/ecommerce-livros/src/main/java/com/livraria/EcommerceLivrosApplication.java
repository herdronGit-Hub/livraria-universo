package com.livraria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.livraria")
public class EcommerceLivrosApplication {
    public static void main(String[] args) {
        SpringApplication.run(EcommerceLivrosApplication.class, args);
    }
}