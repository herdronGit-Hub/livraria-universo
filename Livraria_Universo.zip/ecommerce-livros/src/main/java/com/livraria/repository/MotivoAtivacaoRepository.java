package com.livraria.repository;

import com.livraria.model.MotivoAtivacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MotivoAtivacaoRepository extends JpaRepository<MotivoAtivacao, Integer> {
}