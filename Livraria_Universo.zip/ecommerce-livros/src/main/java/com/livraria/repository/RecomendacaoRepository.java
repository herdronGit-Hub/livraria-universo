package com.livraria.repository;

import com.livraria.model.Cliente;
import com.livraria.model.Recomendacao;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RecomendacaoRepository extends JpaRepository<Recomendacao, Integer> {
    List<Recomendacao> findByCliente(Cliente cliente);
}