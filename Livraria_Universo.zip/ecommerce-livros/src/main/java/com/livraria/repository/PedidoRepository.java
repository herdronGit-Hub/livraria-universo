package com.livraria.repository;

import com.livraria.model.Cliente;
import com.livraria.model.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface PedidoRepository extends JpaRepository<Pedido, Integer> {
    List<Pedido> findByCliente(Cliente cliente);

    @Query("SELECT p FROM Pedido p WHERE p.dataPedido BETWEEN :start AND :end")
    List<Pedido> findByDataRange(@Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
}