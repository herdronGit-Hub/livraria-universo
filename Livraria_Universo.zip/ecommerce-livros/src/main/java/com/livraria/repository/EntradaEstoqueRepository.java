package com.livraria.repository;

import com.livraria.model.EntradaEstoque;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntradaEstoqueRepository extends JpaRepository<EntradaEstoque, Integer> {
}