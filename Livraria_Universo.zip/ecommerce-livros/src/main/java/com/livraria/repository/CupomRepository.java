package com.livraria.repository;

import com.livraria.model.Cupom;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface CupomRepository extends JpaRepository<Cupom, Integer> {
    Cupom findByCodigo(String codigo);
    List<Cupom> findByValidoAteAfter(LocalDate date);
}