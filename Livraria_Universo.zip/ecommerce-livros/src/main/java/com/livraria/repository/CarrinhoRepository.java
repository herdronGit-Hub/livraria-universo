package com.livraria.repository;

import com.livraria.model.Carrinho;
import com.livraria.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CarrinhoRepository extends JpaRepository<Carrinho, Integer> {
    List<Carrinho> findByCliente(Cliente cliente);
}