package com.livraria.repository;

import com.livraria.model.GrupoPrecificacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GrupoPrecificacaoRepository extends JpaRepository<GrupoPrecificacao, Integer> {
}