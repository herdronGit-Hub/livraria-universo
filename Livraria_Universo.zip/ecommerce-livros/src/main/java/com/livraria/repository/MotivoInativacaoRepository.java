package com.livraria.repository;

import com.livraria.model.MotivoInativacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MotivoInativacaoRepository extends JpaRepository<MotivoInativacao, Integer> {
}