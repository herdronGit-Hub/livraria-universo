package com.livraria.repository;

import com.livraria.model.Livro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface LivroRepository extends JpaRepository<Livro, Integer> {
    Page<Livro> findAll(Pageable pageable); // Para todos os livros com paginação
    Page<Livro> findByTituloContainingIgnoreCase(String termo, Pageable pageable); // Para busca com paginação
    Page<Livro> findByTituloContainingIgnoreCaseOrAutorContainingIgnoreCase(String titulo, String autor, Pageable pageable);
}