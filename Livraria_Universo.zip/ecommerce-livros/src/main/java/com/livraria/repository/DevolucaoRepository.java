package com.livraria.repository;

import com.livraria.model.Devolucao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DevolucaoRepository extends JpaRepository<Devolucao, Integer> {
}