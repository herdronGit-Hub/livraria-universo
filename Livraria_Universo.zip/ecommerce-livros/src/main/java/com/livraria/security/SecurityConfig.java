package com.livraria.security;

import com.livraria.repository.ClienteRepository;
import com.livraria.model.Cliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import java.util.Optional;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private ClienteRepository clienteRepository;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(authorize -> authorize
                // Rotas públicas
                .requestMatchers(
                		"/",
                	    "/livro/detalhes",
                	    "/sobre",
                	    "/contato",
                	    "/politicas",
                	    "/login",
                	    "/cadastro",
                	    "/admin/login",
                	    "/css/**",
                	    "/js/**",
                	    "/images/**"
                ).permitAll()
                // Rotas restritas a administradores
                .requestMatchers("/admin/**").hasRole("ADMIN")
                // Todas as outras rotas exigem autenticação
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")              // Página de login personalizada
                .loginProcessingUrl("/login")     // URL que processa o login
                .successHandler(authenticationSuccessHandler())  // Redirecionamento após sucesso
                .failureUrl("/login?error=true")  // Redirecionamento em caso de falha
                .permitAll()                      // Permite acesso público à página de login
            )
            .logout(logout -> logout
                .logoutUrl("/logout")             // URL para logout
                .logoutSuccessUrl("/")            // Redireciona para home após logout
                .permitAll()                      // Permite logout para todos
            );
        return http.build();
    }

    @Bean
    public AuthenticationSuccessHandler authenticationSuccessHandler() {
        return (request, response, authentication) -> {
            System.out.println("Usuário autenticado: " + authentication.getName());
            System.out.println("Papéis: " + authentication.getAuthorities());
            // Redireciona admins para o dashboard e usuários comuns para a home
            if (authentication.getAuthorities().stream()
                    .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals("ROLE_ADMIN"))) {
                response.sendRedirect("/admin/dashboard");
            } else {
                response.sendRedirect("/");
            }
        };
    }

    @Bean
    public UserDetailsService userDetailsService() {
        return username -> {
            System.out.println("Tentando autenticar usuário: " + username);

            // Usuário administrador hardcoded
            if ("admin".equals(username)) {
                System.out.println("Usuário admin encontrado em memória");
                return User.withUsername("admin")
                    .password(passwordEncoder().encode("12345"))  // Senha codificada
                    .roles("ADMIN")
                    .build();
            }

            // Busca cliente no banco de dados
            Optional<Cliente> cliente = clienteRepository.findByEmail(username);
            if (cliente.isPresent()) {
                System.out.println("Cliente encontrado: " + cliente.get().getEmail());
                return User.withUsername(cliente.get().getEmail())
                    .password(cliente.get().getSenha())  // Assume que a senha já está codificada no banco
                    .roles("USER")
                    .build();
            }

            System.out.println("Usuário não encontrado: " + username);
            throw new UsernameNotFoundException("Usuário não encontrado: " + username);
        };
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}