package com.livraria.service;

import com.livraria.model.GrupoPrecificacao;
import com.livraria.repository.GrupoPrecificacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GrupoPrecificacaoService {
    @Autowired
    private GrupoPrecificacaoRepository grupoPrecificacaoRepository;

    public List<GrupoPrecificacao> findAll() {
        return grupoPrecificacaoRepository.findAll();
    }
}