package com.livraria.service;

import com.livraria.model.Cliente;
import com.livraria.model.Endereco;
import com.livraria.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public void cadastrarCliente(Cliente cliente, String confirmacaoSenha) {
        if (!cliente.getSenha().equals(confirmacaoSenha)) {
            throw new IllegalArgumentException("As senhas não coincidem.");
        }
        if (!isSenhaForte(cliente.getSenha())) {
            throw new IllegalArgumentException("A senha deve ter pelo menos 8 caracteres, letras maiúsculas, minúsculas e caracteres especiais.");
        }
        cliente.setSenha(passwordEncoder.encode(cliente.getSenha()));
        validarEnderecos(cliente);
        cliente.getTelefones().forEach(tel -> tel.setCliente(cliente));
        cliente.getEnderecos().forEach(end -> end.setCliente(cliente));
        cliente.getCartoes().forEach(cartao -> cartao.setCliente(cliente));
        clienteRepository.save(cliente);
    }

    public void atualizarCliente(Cliente cliente) {
        Cliente existente = buscarPorId(cliente.getId());
        if (existente == null) {
            throw new IllegalArgumentException("Cliente não encontrado.");
        }
        // Remove as linhas que atualizam genero e dataNascimento
        existente.setNome(cliente.getNome());
        existente.setCpf(cliente.getCpf());
        existente.setEmail(cliente.getEmail());
        
        // Atualiza os endereços apenas se a lista não estiver vazia
        if (cliente.getEnderecos() != null && !cliente.getEnderecos().isEmpty()) {
            validarEnderecos(cliente);
            existente.getEnderecos().clear();
            existente.getEnderecos().addAll(cliente.getEnderecos());
            existente.getEnderecos().forEach(end -> end.setCliente(existente));
        } else {
            validarEnderecos(existente);
        }

        existente.getTelefones().clear();
        existente.getTelefones().addAll(cliente.getTelefones());
        existente.getTelefones().forEach(tel -> tel.setCliente(existente));
        existente.getCartoes().clear();
        existente.getCartoes().addAll(cliente.getCartoes());
        existente.getCartoes().forEach(cartao -> cartao.setCliente(existente));
        clienteRepository.save(existente);
    }

    public void atualizarEnderecos(Cliente cliente) {
        Cliente existente = buscarPorId(cliente.getId());
        if (existente == null) {
            throw new IllegalArgumentException("Cliente não encontrado.");
        }
        validarEnderecos(cliente);
        existente.getEnderecos().clear();
        existente.getEnderecos().addAll(cliente.getEnderecos());
        existente.getEnderecos().forEach(end -> end.setCliente(existente));
        clienteRepository.save(existente);
    }

    public void alterarSenha(Integer id, String novaSenha, String confirmacaoSenha) {
        Cliente cliente = buscarPorId(id);
        if (cliente == null) {
            throw new IllegalArgumentException("Cliente não encontrado.");
        }
        if (!novaSenha.equals(confirmacaoSenha)) {
            throw new IllegalArgumentException("As senhas não coincidem.");
        }
        if (!isSenhaForte(novaSenha)) {
            throw new IllegalArgumentException("A senha deve ter pelo menos 8 caracteres, letras maiúsculas, minúsculas e caracteres especiais.");
        }
        cliente.setSenha(passwordEncoder.encode(novaSenha));
        clienteRepository.save(cliente);
    }

    public List<Cliente> listarTodos() {
        return clienteRepository.findAll();
    }

    public Cliente buscarPorId(Integer id) {
        return clienteRepository.findById(id).orElse(null);
    }

    public Cliente buscarPorEmail(String email) {
        return clienteRepository.findByEmail(email).orElse(null);
    }

    public List<Cliente> buscarPorFiltros(String nome, String cpf, String email) {
        return clienteRepository.findAll().stream()
                .filter(c -> (nome == null || c.getNome().toLowerCase().contains(nome.toLowerCase())))
                .filter(c -> (cpf == null || c.getCpf().equals(cpf)))
                .filter(c -> (email == null || c.getEmail().toLowerCase().contains(email.toLowerCase())))
                .collect(Collectors.toList());
    }

    public void inativarCliente(Integer id) {
        Cliente cliente = buscarPorId(id);
        if (cliente != null) {
            cliente.setAtivo(false);
            clienteRepository.save(cliente);
        }
    }

    private void validarEnderecos(Cliente cliente) {
        boolean hasCobranca = cliente.getEnderecos().stream().anyMatch(Endereco::getCobranca);
        boolean hasEntrega = cliente.getEnderecos().stream().anyMatch(Endereco::getEntrega);
        if (!hasCobranca) {
            throw new IllegalArgumentException("É necessário um endereço de cobrança.");
        }
        if (!hasEntrega) {
            throw new IllegalArgumentException("É necessário um endereço de entrega.");
        }
    }

    private boolean isSenhaForte(String senha) {
        return senha.length() >= 8 &&
               senha.matches(".*[A-Z].*") &&
               senha.matches(".*[a-z].*") &&
               senha.matches(".*[!@#$%^&*].*");
    }
}