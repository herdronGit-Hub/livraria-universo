package com.livraria.service;

import com.livraria.model.Devolucao;
import com.livraria.model.Pedido;
import org.springframework.stereotype.Service;

@Service
public class DevolucaoService {

    public Pedido findById(int pedidoId) {
        // Lógica para buscar o pedido (exemplo simplificado)
        return new Pedido();
    }

    public void solicitarTroca(Devolucao devolucao) {
        // Lógica para processar a devolução com o objeto Devolucao
        // Ex.: salvar no banco ou atualizar o pedido
    }

    // Método antigo mantido para compatibilidade, se necessário
    public void solicitarTroca(int pedidoId, String motivo) {
        Devolucao devolucao = new Devolucao();
        devolucao.setPedido(findById(pedidoId));
        devolucao.setMotivo(motivo);
        solicitarTroca(devolucao);
    }
}