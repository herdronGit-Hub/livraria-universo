package com.livraria.service;

import com.livraria.model.Livro;
import com.livraria.repository.LivroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LivroService {

    @Autowired
    private LivroRepository livroRepository;

    public Page<Livro> findMaisVendidos(Pageable pageable) {
        return livroRepository.findAll(pageable); // Ajuste para lógica real de "mais vendidos" se necessário
    }

    public Page<Livro> findAll(Pageable pageable) {
        return livroRepository.findAll(pageable);
    }

    public Page<Livro> findByTituloOuAutor(String termo, Pageable pageable) {
        return livroRepository.findByTituloContainingIgnoreCaseOrAutorContainingIgnoreCase(termo, termo, pageable);
    }

    public Optional<Livro> findById(Integer id) {
        return livroRepository.findById(id);
    }
}