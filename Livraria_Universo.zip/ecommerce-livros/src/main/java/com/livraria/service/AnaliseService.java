package com.livraria.service;

import com.livraria.model.Pedido;
import com.livraria.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AnaliseService {
    @Autowired
    private PedidoRepository pedidoRepository;

    public Map<String, Double> getHistoricoVendas() {
        LocalDateTime inicio = LocalDateTime.now().minusMonths(12);
        LocalDateTime fim = LocalDateTime.now();
        List<Pedido> pedidos = pedidoRepository.findByDataRange(inicio, fim);

        return pedidos.stream()
                .collect(Collectors.groupingBy(
                        p -> p.getDataPedido().toLocalDate().toString(),
                        Collectors.summingDouble(Pedido::getTotal)
                ));
    }
}