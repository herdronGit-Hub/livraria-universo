package com.livraria.service;

import com.livraria.model.Cliente;
import com.livraria.model.CartaoCredito;
import com.livraria.repository.CartaoCreditoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartaoCreditoService {
    @Autowired
    private CartaoCreditoRepository cartaoCreditoRepository;

    public CartaoCredito salvar(CartaoCredito cartao, Cliente cliente) {
        if (cartao.isPreferencial()) {
            List<CartaoCredito> cartoes = cartaoCreditoRepository.findByCliente(cliente);
            for (CartaoCredito c : cartoes) {
                c.setPreferencial(false);
                cartaoCreditoRepository.save(c);
            }
        }
        cartao.setCliente(cliente);
        return cartaoCreditoRepository.save(cartao);
    }

    public List<CartaoCredito> listarPorCliente(Cliente cliente) {
        return cartaoCreditoRepository.findByCliente(cliente);
    }
}