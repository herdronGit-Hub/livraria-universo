package com.livraria.service;

import com.livraria.model.Cliente;
import com.livraria.model.Endereco;
import com.livraria.repository.EnderecoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnderecoService {
    @Autowired
    private EnderecoRepository enderecoRepository;

    public Endereco salvar(Endereco endereco) {
        return enderecoRepository.save(endereco);
    }

    public List<Endereco> listarPorCliente(Cliente cliente) {
        return enderecoRepository.findByCliente(cliente);
    }
}