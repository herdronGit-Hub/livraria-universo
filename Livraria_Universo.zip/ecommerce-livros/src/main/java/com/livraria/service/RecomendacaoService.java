package com.livraria.service;

import com.livraria.model.Cliente;
import com.livraria.model.ItemPedido;
import com.livraria.model.Pedido;
import com.livraria.model.Recomendacao;
import com.livraria.repository.RecomendacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RecomendacaoService {

    @Autowired
    private RecomendacaoRepository recomendacaoRepository;
    
 // Renomeado de gerarRecomendacoes para getRecomendacoes
    public List<Recomendacao> getRecomendacoes(Cliente cliente) {
        List<Pedido> pedidos = cliente.getPedidos();
        List<Recomendacao> recomendacoes = new ArrayList<>();

        // Lógica simples: recomendar livros baseados em compras anteriores
        for (Pedido pedido : pedidos) {
            for (ItemPedido item : pedido.getItens()) {
                Recomendacao rec = new Recomendacao();
                rec.setCliente(cliente);
                rec.setLivro(item.getLivro());
                rec.setMotivo("Recomendado com base no seu pedido anterior: " + pedido.getId());
                recomendacoes.add(rec);
            }
        }

        // Salvar as recomendações no repositório (opcional)
        if (!recomendacoes.isEmpty()) {
            recomendacaoRepository.saveAll(recomendacoes);
        }

        return recomendacaoRepository.findByCliente(cliente);
    }

    // Novo método para responder perguntas do chatbot
    public String responderPergunta(String pergunta, Cliente cliente) {
        // Lógica simples para o chatbot
        if (pergunta.toLowerCase().contains("recomendar")) {
            List<Recomendacao> recomendacoes = getRecomendacoes(cliente);
            if (!recomendacoes.isEmpty()) {
                Recomendacao rec = recomendacoes.get(0); // Pega a primeira recomendação como exemplo
                return "Aqui está uma recomendação para você: " + rec.getLivro().getTitulo() + " (" + rec.getMotivo() + ")";
            } else {
                return "Não encontrei recomendações no momento. Que tal fazer um pedido?";
            }
        }
        return "Desculpe, não entendi sua pergunta. Tente dizer 'recomendar' para sugestões!";
    }

    public List<Recomendacao> gerarRecomendacoes(Cliente cliente) {
        List<Pedido> pedidos = cliente.getPedidos(); // Agora usada
        List<Recomendacao> recomendacoes = new ArrayList<>();

        // Lógica simples: recomendar livros baseados em compras anteriores
        for (Pedido pedido : pedidos) {
            for (ItemPedido item : pedido.getItens()) {
                Recomendacao rec = new Recomendacao();
                rec.setCliente(cliente);
                rec.setLivro(item.getLivro());
                rec.setMotivo("Recomendado com base no seu pedido anterior: " + pedido.getId());
                recomendacoes.add(rec);
            }
        }

        // Salvar as recomendações no repositório (opcional)
        if (!recomendacoes.isEmpty()) {
            recomendacaoRepository.saveAll(recomendacoes);
        }

        return recomendacaoRepository.findByCliente(cliente);
    }

    // Outros métodos...
}