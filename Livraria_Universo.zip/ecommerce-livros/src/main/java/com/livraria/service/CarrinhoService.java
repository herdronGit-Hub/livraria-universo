package com.livraria.service;

import com.livraria.model.Carrinho;
import com.livraria.model.Cliente;
import com.livraria.model.Livro;
import com.livraria.repository.CarrinhoRepository;
import com.livraria.repository.LivroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarrinhoService {
    @Autowired
    private CarrinhoRepository carrinhoRepository;
    @Autowired
    private LivroRepository livroRepository;

    public void adicionar(int livroId, int quantidade, Cliente cliente) {
        Livro livro = livroRepository.findById(livroId).orElseThrow();
        if (livro.getEstoque() < quantidade) {
            throw new IllegalArgumentException("Quantidade indisponível em estoque.");
        }
        livro.setEstoque(livro.getEstoque() - quantidade);
        livroRepository.save(livro);

        Carrinho item = new Carrinho();
        item.setCliente(cliente);
        item.setLivro(livro);
        item.setQuantidade(quantidade);
        carrinhoRepository.save(item);
    }

    public void validarEstoqueAntesFinalizar(Cliente cliente) {
        List<Carrinho> itens = carrinhoRepository.findByCliente(cliente);
        for (Carrinho item : itens) {
            Livro livro = item.getLivro();
            if (livro.getEstoque() < item.getQuantidade()) {
                if (livro.getEstoque() == 0) {
                    carrinhoRepository.delete(item);
                } else {
                    item.setQuantidade(livro.getEstoque());
                    carrinhoRepository.save(item);
                }
            }
        }
    }

    public List<Carrinho> listarItens(Cliente cliente) {
        return carrinhoRepository.findByCliente(cliente);
    }
}