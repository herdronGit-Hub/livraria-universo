package com.livraria.service;

import com.livraria.model.Cupom;
import com.livraria.repository.CupomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class CupomService {
    @Autowired
    private CupomRepository cupomRepository;

    public List<Cupom> listarCuponsValidos() {
        return cupomRepository.findByValidoAteAfter(LocalDate.now());
    }
}