package com.livraria.service;

import com.livraria.model.EntradaEstoque; // Import necessário
import com.livraria.model.Livro;
import com.livraria.repository.LivroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EstoqueService {

    @Autowired
    private LivroRepository livroRepository;

    public void registrarEntrada(EntradaEstoque entradaEstoque) {
        Livro livro = livroRepository.findById(entradaEstoque.getLivro().getId())
                .orElseThrow(() -> new IllegalArgumentException("Livro não encontrado: " + entradaEstoque.getLivro().getId()));
        livro.setEstoque(livro.getEstoque() + entradaEstoque.getQuantidade());
        livroRepository.save(livro);
        // Aqui você pode adicionar lógica para salvar a entradaEstoque em um repositório, se necessário
    }

    public void adicionarEstoque(int livroId, int quantidade) {
        Livro livro = livroRepository.findById(livroId).orElseThrow();
        livro.setEstoque(livro.getEstoque() + quantidade);
        livroRepository.save(livro);
    }

    // Outros métodos...
}