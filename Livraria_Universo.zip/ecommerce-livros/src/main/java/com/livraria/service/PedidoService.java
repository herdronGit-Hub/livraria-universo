package com.livraria.service;

import com.livraria.model.*;
import com.livraria.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class PedidoService {
    @Autowired
    private PedidoRepository pedidoRepository;
    @Autowired
    private CarrinhoRepository carrinhoRepository;
    @Autowired
    private ItemPedidoRepository itemPedidoRepository;
    @Autowired
    private CupomRepository cupomRepository;
    @Autowired
    private LivroRepository livroRepository;
    @Autowired
    private DevolucaoRepository devolucaoRepository;

    public Pedido finalizarCompra(Cliente cliente, String codigoCupom, List<PagamentoCartao> pagamentosCartao) {
        validarEstoqueAntesFinalizar(cliente);
        List<Carrinho> itens = carrinhoRepository.findByCliente(cliente);
        if (itens.isEmpty()) return null;

        Pedido pedido = new Pedido();
        pedido.setCliente(cliente);
        pedido.setDataPedido(LocalDateTime.now());
        pedido.setStatus("EM PROCESSAMENTO");
        pedidoRepository.save(pedido);

        double total = 0;
        for (Carrinho item : itens) {
            ItemPedido itemPedido = new ItemPedido();
            itemPedido.setPedido(pedido);
            itemPedido.setLivro(item.getLivro());
            itemPedido.setQuantidade(item.getQuantidade());
            itemPedido.setPrecoUnitario(item.getLivro().getPreco());
            total += item.getQuantidade() * item.getLivro().getPreco();
            itemPedidoRepository.save(itemPedido);
        }

        double descontoCupom = 0;
        if (codigoCupom != null) {
            Cupom cupom = cupomRepository.findByCodigo(codigoCupom);
            if (cupom != null && cupom.getValidoAte().isAfter(LocalDate.now())) {
                descontoCupom = total * (cupom.getDesconto() / 100);
                total -= descontoCupom;
            }
        }

        double totalCartoes = 0;
        for (PagamentoCartao pagamento : pagamentosCartao) {
            if (total - descontoCupom < 10 && pagamento.getValor() < 10) {
                // Permitido apenas com cupom
            } else if (pagamento.getValor() < 10) {
                throw new IllegalArgumentException("Valor mínimo por cartão é R$10,00.");
            }
            totalCartoes += pagamento.getValor();
        }
        if (totalCartoes + descontoCupom < total) {
            throw new IllegalArgumentException("Pagamento insuficiente.");
        }

        if (totalCartoes + descontoCupom > total) {
            Cupom cupomTroca = new Cupom();
            cupomTroca.setCodigo("TROCA-" + System.currentTimeMillis());
            cupomTroca.setDesconto(totalCartoes + descontoCupom - total);
            cupomTroca.setValidoAte(LocalDate.now().plusMonths(6));
            cupomRepository.save(cupomTroca);
        }

        if (validarPagamento(pagamentosCartao)) {
            pedido.setStatus("APROVADA");
        } else {
            pedido.setStatus("REPROVADA");
            liberarEstoque(itens);
        }

        pedido.setTotal(total);
        pedidoRepository.save(pedido); // Corrigido de 'pedido' em vez de 'pedo'
        carrinhoRepository.deleteAll(itens);
        return pedido;
    }

    private boolean validarPagamento(List<PagamentoCartao> pagamentos) {
        return true; // Simulação
    }

    private void liberarEstoque(List<Carrinho> itens) {
        for (Carrinho item : itens) {
            Livro livro = item.getLivro();
            livro.setEstoque(livro.getEstoque() + item.getQuantidade());
            livroRepository.save(livro);
        }
    }

    private void validarEstoqueAntesFinalizar(Cliente cliente) {
        List<Carrinho> itens = carrinhoRepository.findByCliente(cliente);
        for (Carrinho item : itens) {
            Livro livro = item.getLivro();
            if (livro.getEstoque() < item.getQuantidade()) {
                if (livro.getEstoque() == 0) {
                    carrinhoRepository.delete(item);
                } else {
                    item.setQuantidade(livro.getEstoque());
                    carrinhoRepository.save(item);
                }
            }
        }
    }

    public List<Pedido> listarPedidosPorCliente(Cliente cliente) {
        return pedidoRepository.findByCliente(cliente);
    }

    public Pedido findById(int id) {
        return pedidoRepository.findById(id).orElseThrow();
    }

    public void solicitarTroca(int pedidoId, String motivo) {
        Pedido pedido = findById(pedidoId);
        if (!"ENTREGUE".equals(pedido.getStatus())) {
            throw new IllegalStateException("Troca só pode ser solicitada para pedidos entregues.");
        }
        Devolucao devolucao = new Devolucao();
        devolucao.setPedido(pedido);
        devolucao.setMotivo(motivo);
        devolucao.setDataSolicitacao(LocalDateTime.now());
        devolucao.setStatus("EM TROCA");
        devolucaoRepository.save(devolucao);
        pedido.setStatus("EM TROCA");
        pedidoRepository.save(pedido); // Corrigido de 'pedido' em vez de 'pedo'
    }
}