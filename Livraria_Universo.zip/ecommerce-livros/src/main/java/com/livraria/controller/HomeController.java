package com.livraria.controller;

import com.livraria.model.Cliente;
import com.livraria.model.Livro;
import com.livraria.service.ClienteService;
import com.livraria.service.LivroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    @Autowired
    private LivroService livroService;

    @Autowired
    private ClienteService clienteService;

    @GetMapping("/livro/detalhes")
    public String detalhesLivro(@RequestParam("id") Integer id, Model model) {
        try {
            Livro livro = livroService.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Livro não encontrado: " + id));
            model.addAttribute("livro", livro);
            return "detalhes";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "error";
        }
    }

    @GetMapping("/")
    public String home(@RequestParam(value = "query", required = false) String termoBusca,
                       @RequestParam(value = "page", defaultValue = "0") int page,
                       @RequestParam(value = "size", defaultValue = "10") int size,
                       Model model, Authentication authentication) {
        // Validação de parâmetros
        if (page < 0) page = 0;
        if (size <= 0) size = 10;

        Pageable pageable = PageRequest.of(page, size);

        // Mensagem de boas-vindas
        if (authentication != null && authentication.isAuthenticated() && 
            !authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            String email = authentication.getName();
            Cliente cliente = clienteService.buscarPorEmail(email);
            if (cliente != null) {
                model.addAttribute("mensagem", "Bem-vindo, " + cliente.getNome() + "!");
            }
        }

        // Listagem de livros
        if (termoBusca != null && !termoBusca.trim().isEmpty()) {
            Page<Livro> livrosEncontrados = livroService.findByTituloOuAutor(termoBusca.trim(), pageable);
            model.addAttribute("livrosEncontrados", livrosEncontrados.getContent());
            model.addAttribute("termoBusca", termoBusca);
            model.addAttribute("currentPage", livrosEncontrados.getNumber());
            model.addAttribute("totalPages", livrosEncontrados.getTotalPages());
            model.addAttribute("totalItems", livrosEncontrados.getTotalElements());
        } else {
            Page<Livro> livrosMaisVendidos = livroService.findMaisVendidos(pageable);
            model.addAttribute("livrosMaisVendidos", livrosMaisVendidos.getContent());
            model.addAttribute("currentPage", livrosMaisVendidos.getNumber());
            model.addAttribute("totalPages", livrosMaisVendidos.getTotalPages());
            model.addAttribute("totalItems", livrosMaisVendidos.getTotalElements());
        }

        return "index";
    }
}