package com.livraria.controller;

import com.livraria.model.EntradaEstoque;
import com.livraria.service.EstoqueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/estoque")
public class EstoqueController {
    @Autowired
    private EstoqueService estoqueService;

    @GetMapping("/entrada")
    public String entradaEstoquePage(Model model) {
        model.addAttribute("entrada", new EntradaEstoque());
        return "entrada-estoque";
    }

    @PostMapping("/entrada")
    public String registrarEntrada(@ModelAttribute EntradaEstoque entrada) {
        estoqueService.registrarEntrada(entrada);
        return "redirect:/livros";
    }
}