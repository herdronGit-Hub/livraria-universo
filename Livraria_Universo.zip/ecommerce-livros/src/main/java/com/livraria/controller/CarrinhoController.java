package com.livraria.controller;

import com.livraria.model.Cliente;
import com.livraria.model.PagamentoCartao;
import com.livraria.service.CarrinhoService;
import com.livraria.service.PedidoService;
import com.livraria.service.CartaoCreditoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/carrinho")
public class CarrinhoController {
    @Autowired
    private CarrinhoService carrinhoService;
    @Autowired
    private PedidoService pedidoService;
    @Autowired
    private CartaoCreditoService cartaoCreditoService; // Adicionada injeção

    @GetMapping
    public String verCarrinho(Model model, @SessionAttribute("cliente") Cliente cliente) {
        model.addAttribute("itens", carrinhoService.listarItens(cliente));
        model.addAttribute("cartoes", cartaoCreditoService.listarPorCliente(cliente));
        return "carrinho";
    }

    @PostMapping("/adicionar")
    public String adicionarAoCarrinho(@RequestParam int livroId, @RequestParam int quantidade, @SessionAttribute("cliente") Cliente cliente) {
        carrinhoService.adicionar(livroId, quantidade, cliente);
        return "redirect:/carrinho";
    }

    @PostMapping("/finalizar")
    public String finalizarCompra(@RequestParam(required = false) String codigoCupom, 
                                  @RequestParam Map<String, String> allParams, 
                                  @SessionAttribute("cliente") Cliente cliente) {
        List<PagamentoCartao> pagamentos = allParams.entrySet().stream()
                .filter(e -> e.getKey().startsWith("pagamentosCartao"))
                .map(e -> {
                    PagamentoCartao p = new PagamentoCartao();
                    p.setCartaoId(Integer.parseInt(e.getKey().split("\\[")[1].replace("].valor", "")));
                    p.setValor(Double.parseDouble(e.getValue()));
                    return p;
                })
                .collect(Collectors.toList());
        pedidoService.finalizarCompra(cliente, codigoCupom, pagamentos);
        return "redirect:/pedidos";
    }
}