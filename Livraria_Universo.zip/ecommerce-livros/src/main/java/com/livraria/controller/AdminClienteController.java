package com.livraria.controller;

import com.livraria.model.Cliente;
import com.livraria.repository.ClienteRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/admin/clientes")
public class AdminClienteController {

    private static final Logger logger = LoggerFactory.getLogger(AdminClienteController.class);

    @Autowired
    private ClienteRepository clienteRepository;

    @GetMapping("/novo")
    public String novoCliente(Model model) {
        logger.info("Acessando formulário de novo cliente");
        model.addAttribute("cliente", new Cliente());
        return "admin-clientes-salvar";
    }

    @GetMapping("/editar/{id}")
    public String editarCliente(@PathVariable("id") Integer id, Model model) { // Alterado de Integer para Long
        logger.info("Acessando formulário de edição para cliente com ID: {}", id);
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Cliente não encontrado: " + id));
        model.addAttribute("cliente", cliente);
        return "admin-clientes-salvar";
    }

    @PostMapping("/salvar")
    public String salvarCliente(@Valid Cliente cliente,
                                @RequestParam(value = "confirmacaoSenha", required = false) String confirmacaoSenha,
                                BindingResult result,
                                RedirectAttributes redirectAttributes) {
        logger.info("Entrando em salvarCliente com cliente: {}", cliente.toString());
        logger.info("ConfirmacaoSenha recebida: {}", confirmacaoSenha);

        if (result.hasErrors()) {
            logger.info("Erros de validação encontrados");
            return "admin-clientes-salvar";
        }

        if (cliente.getId() == null) {
            if (confirmacaoSenha == null || !confirmacaoSenha.equals(cliente.getSenha())) {
                logger.info("Senhas não coincidem");
                result.rejectValue("senha", "error.cliente", "As senhas não coincidem.");
                return "admin-clientes-salvar";
            }
        }

        try {
            if (cliente.getId() == null) {
                logger.info("Cadastrando novo cliente");
                cliente.setAtivo(true);
                cliente.setRanking(0);
                clienteRepository.save(cliente);
                redirectAttributes.addFlashAttribute("success", "Cliente cadastrado com sucesso!");
            } else {
                logger.info("Atualizando cliente existente com ID: {}", cliente.getId());
                Cliente existente = clienteRepository.findById(cliente.getId())
                        .orElseThrow(() -> new IllegalArgumentException("Cliente não encontrado"));
                existente.setNome(cliente.getNome());
                existente.setCpf(cliente.getCpf());
                existente.setEmail(cliente.getEmail());
                if (cliente.getSenha() != null && !cliente.getSenha().isEmpty()) {
                    existente.setSenha(cliente.getSenha());
                }
                clienteRepository.save(existente);
                redirectAttributes.addFlashAttribute("success", "Cliente atualizado com sucesso!");
            }
        } catch (Exception e) {
            logger.error("Erro ao salvar cliente: {}", e.getMessage());
            redirectAttributes.addFlashAttribute("erro", "Erro ao salvar cliente: " + e.getMessage());
            return "redirect:/admin/clientes/manutencao";
        }

        return "redirect:/admin/clientes/manutencao";
    }

    @GetMapping("/manutencao")
    public String manutencaoClientes(Model model) {
        logger.info("Acessando página de manutenção de clientes");
        Iterable<Cliente> clientes = clienteRepository.findAll();
        model.addAttribute("clientes", clientes);
        return "admin-clientes-manutencao";
    }
}