package com.livraria.controller;

import com.livraria.service.AnaliseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/analise")
public class AnaliseController {
    @Autowired
    private AnaliseService analiseService;

    @GetMapping
    public String analiseVendas(Model model) {
        model.addAttribute("vendas", analiseService.getHistoricoVendas());
        return "analise-vendas";
    }
}