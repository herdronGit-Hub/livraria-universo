package com.livraria.controller;

import com.livraria.model.Cliente;
import com.livraria.model.Endereco;
import com.livraria.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.validation.Valid;

@Controller
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @GetMapping("/cadastro")
    public String exibirFormulario(Model model) {
        Cliente cliente = new Cliente();
        cliente.getEnderecos().add(new Endereco()); // Endereço inicial (cobrança)
        cliente.getEnderecos().get(0).setCobranca(true);
        cliente.getEnderecos().add(new Endereco()); // Endereço inicial (entrega)
        cliente.getEnderecos().get(1).setEntrega(true);
        model.addAttribute("cliente", cliente);
        return "cadastro";
    }

    @PostMapping("/cadastro")
    public String cadastrarCliente(
            @Valid @ModelAttribute("cliente") Cliente cliente,
            BindingResult result,
            @RequestParam("confirmacaoSenha") String confirmacaoSenha,
            Model model) {
        if (result.hasErrors()) {
            return "cadastro";
        }
        try {
            clienteService.cadastrarCliente(cliente, confirmacaoSenha); // Passando confirmacaoSenha
            return "redirect:/cadastro?success";
        } catch (Exception e) {
            model.addAttribute("erro", e.getMessage());
            return "cadastro";
        }
    }
}