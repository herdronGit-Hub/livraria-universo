package com.livraria.controller;

import com.livraria.model.Cliente;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.livraria.service.PedidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/pedidos")
public class PedidoController {
    @Autowired
    private PedidoService pedidoService;

    @GetMapping
    public String listarPedidos(Model model, @SessionAttribute("cliente") Cliente cliente) {
        model.addAttribute("pedidos", pedidoService.listarPedidosPorCliente(cliente));
        return "lista-pedidos";
    }
}