package com.livraria.controller;

import com.livraria.model.Cliente;
import com.livraria.service.RecomendacaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/recomendacoes")
public class RecomendacaoController {
    @Autowired
    private RecomendacaoService recomendacaoService;

    @GetMapping
    public String recomendacoes(Model model, @SessionAttribute("cliente") Cliente cliente) {
        model.addAttribute("recomendacoes", recomendacaoService.getRecomendacoes(cliente));
        return "recomendacoes";
    }

    @PostMapping("/chatbot")
    @ResponseBody
    public String chatbot(@RequestParam String pergunta, @SessionAttribute("cliente") Cliente cliente) {
        return recomendacaoService.responderPergunta(pergunta, cliente);
    }
}