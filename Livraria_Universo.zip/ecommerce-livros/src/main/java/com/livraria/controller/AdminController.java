package com.livraria.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @GetMapping("/login")
    public String adminLogin(Model model) {
        logger.info("Entrando na página de login do administrador via GET");
        return "admin-login";
    }

    @GetMapping("/dashboard")
    public String adminDashboard(Model model) {
        logger.info("Entrando no adminDashboard via GET");
        model.addAttribute("mensagem", "Bem-vindo ao Dashboard do Administrador!");
        logger.info("Mensagem adicionada ao modelo");
        return "admin-dashboard";
    }
}