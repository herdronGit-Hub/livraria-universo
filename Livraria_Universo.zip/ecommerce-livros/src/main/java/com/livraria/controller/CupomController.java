package com.livraria.controller;

import com.livraria.service.CupomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/cupons")
public class CupomController {
    @Autowired
    private CupomService cupomService;

    @GetMapping
    public String listarCupons(Model model) {
        model.addAttribute("cupons", cupomService.listarCuponsValidos());
        return "lista-cupons";
    }
}