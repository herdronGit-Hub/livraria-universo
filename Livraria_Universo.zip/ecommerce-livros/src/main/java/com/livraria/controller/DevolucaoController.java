package com.livraria.controller;

import com.livraria.model.Devolucao; // Agora usada
import com.livraria.service.DevolucaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/devolucao")
public class DevolucaoController {

    @Autowired
    private DevolucaoService devolucaoService;

    @GetMapping("/solicitar")
    public String solicitarDevolucao(@RequestParam("pedidoId") int pedidoId, Model model) {
        model.addAttribute("pedido", devolucaoService.findById(pedidoId));
        model.addAttribute("devolucao", new Devolucao()); // Adiciona um objeto Devolucao ao modelo
        return "solicitar-devolucao";
    }

    @PostMapping("/solicitar")
    public String processarSolicitacao(@RequestParam("pedidoId") int pedidoId, @RequestParam("motivo") String motivo) {
        Devolucao devolucao = new Devolucao(); // Usando a classe Devolucao
        devolucao.setPedido(devolucaoService.findById(pedidoId));
        devolucao.setMotivo(motivo);
        devolucaoService.solicitarTroca(devolucao); // Passa o objeto Devolucao ao serviço
        return "redirect:/pedidos";
    }
}