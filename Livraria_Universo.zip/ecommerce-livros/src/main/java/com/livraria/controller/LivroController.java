package com.livraria.controller;

import com.livraria.model.Livro; // Importação adicionada
import com.livraria.service.LivroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LivroController {

    @Autowired
    private LivroService livroService;

    @GetMapping("/livros")
    public String listarLivros(Model model,
                               @RequestParam(value = "page", defaultValue = "0") int page,
                               @RequestParam(value = "size", defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Livro> livrosPage = livroService.findAll(pageable);

        model.addAttribute("livros", livrosPage.getContent()); // Lista de livros na página atual
        model.addAttribute("currentPage", livrosPage.getNumber()); // Página atual
        model.addAttribute("totalPages", livrosPage.getTotalPages()); // Total de páginas

        return "livros"; // Nome do template para listar todos os livros
    }
}