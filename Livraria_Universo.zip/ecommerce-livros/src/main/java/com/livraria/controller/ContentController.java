package com.livraria.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ContentController {

    @GetMapping("/sobre")
    public String sobre(Model model) {
        model.addAttribute("titulo", "Sobre Nós");
        return "sobre";
    }

    @GetMapping("/contato")
    public String contato(Model model) {
        model.addAttribute("titulo", "Contato");
        return "contato";
    }

    @GetMapping("/politicas")
    public String politicas(Model model) {
        model.addAttribute("titulo", "Políticas");
        return "politicas";
    }
}