package com.livraria.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "livros")
public class Livro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Adicionei auto-incremento, já que é comum para IDs
    private Integer id;

    @Column(nullable = false)
    private String autor;

    private String ano;

    @Column(nullable = false)
    private String titulo;

    private String editora;

    private String edicao;

    private String isbn;

    private Integer numeroPaginas;

    private String sinopse;

    private BigDecimal altura;

    private BigDecimal largura;

    private BigDecimal peso;

    private BigDecimal profundidade;

    private String codigoBarras;

    @Column(nullable = false)
    private BigDecimal preco;

    @Column(nullable = false)
    private Integer estoque;

    @Column(nullable = false, columnDefinition = "BOOLEAN DEFAULT TRUE")
    private Boolean ativo = true;

    @ManyToOne
    @JoinColumn(name = "grupo_precificacao_id")
    private GrupoPrecificacao grupoPrecificacao;

    @Column // Adicionando o campo imagem
    private String imagem;

    // Getters e Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }
    public String getAno() { return ano; }
    public void setAno(String ano) { this.ano = ano; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getEditora() { return editora; }
    public void setEditora(String editora) { this.editora = editora; }
    public String getEdicao() { return edicao; }
    public void setEdicao(String edicao) { this.edicao = edicao; }
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public Integer getNumeroPaginas() { return numeroPaginas; }
    public void setNumeroPaginas(Integer numeroPaginas) { this.numeroPaginas = numeroPaginas; }
    public String getSinopse() { return sinopse; }
    public void setSinopse(String sinopse) { this.sinopse = sinopse; }
    public BigDecimal getAltura() { return altura; }
    public void setAltura(BigDecimal altura) { this.altura = altura; }
    public BigDecimal getLargura() { return largura; }
    public void setLargura(BigDecimal largura) { this.largura = largura; }
    public BigDecimal getPeso() { return peso; }
    public void setPeso(BigDecimal peso) { this.peso = peso; }
    public BigDecimal getProfundidade() { return profundidade; }
    public void setProfundidade(BigDecimal profundidade) { this.profundidade = profundidade; }
    public String getCodigoBarras() { return codigoBarras; }
    public void setCodigoBarras(String codigoBarras) { this.codigoBarras = codigoBarras; }
    public BigDecimal getPreco() { return preco; }
    public void setPreco(BigDecimal preco) { this.preco = preco; }
    public Integer getEstoque() { return estoque; }
    public void setEstoque(Integer estoque) { this.estoque = estoque; }
    public Boolean getAtivo() { return ativo; }
    public void setAtivo(Boolean ativo) { this.ativo = ativo; }
    public GrupoPrecificacao getGrupoPrecificacao() { return grupoPrecificacao; }
    public void setGrupoPrecificacao(GrupoPrecificacao grupoPrecificacao) { this.grupoPrecificacao = grupoPrecificacao; }
    public String getImagem() { return imagem; } // Getter para imagem
    public void setImagem(String imagem) { this.imagem = imagem; } // Setter para imagem
}