package com.livraria.model;

public class PagamentoCartao {
    private int cartaoId;
    private double valor;

    // Getters e Setters
    public int getCartaoId() { return cartaoId; }
    public void setCartaoId(int cartaoId) { this.cartaoId = cartaoId; }
    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }
}