package com.livraria.model;

import jakarta.persistence.*;

@Entity
@Table(name = "motivos_ativacao")
public class MotivoAtivacao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String justificativa;
    private String categoria;

    @ManyToOne
    @JoinColumn(name = "livro_id")
    private Livro livro;

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getJustificativa() { return justificativa; }
    public void setJustificativa(String justificativa) { this.justificativa = justificativa; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public Livro getLivro() { return livro; }
    public void setLivro(Livro livro) { this.livro = livro; }
}