package com.livraria.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "cupons")
public class Cupom {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String codigo;
    private double desconto;
    private LocalDate validoAte;

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public double getDesconto() { return desconto; }
    public void setDesconto(double desconto) { this.desconto = desconto; }
    public LocalDate getValidoAte() { return validoAte; }
    public void setValidoAte(LocalDate validoAte) { this.validoAte = validoAte; }
}